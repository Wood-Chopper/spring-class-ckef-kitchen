package com.something.agency.controller;

public class RealEstateController {
    // TODO Update the price of a real estate
}
