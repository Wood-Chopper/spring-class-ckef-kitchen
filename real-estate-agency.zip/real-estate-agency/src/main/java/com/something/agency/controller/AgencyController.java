package com.something.agency.controller;

public class AgencyController {
    // TODO Add an agency

    // TODO Get an agency

    // TODO Add a real estate to an agency
}
